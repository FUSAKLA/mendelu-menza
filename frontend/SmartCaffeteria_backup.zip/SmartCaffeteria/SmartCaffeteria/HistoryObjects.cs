﻿using System;
namespace SmartCaffeteria
{
	public struct HistoryObjects
	{
		public HistoryObject[] history;
	}
}
