﻿using System;
namespace SmartCaffeteria
{
	public struct IntervalObjects
	{
		public IntervalObject[] intervals;
	}
}
