﻿using System;
namespace SmartCaffeteria
{
	public enum Method
	{
		GET, 
		POST, 
		PUT, 
		DELETE
	}
}
