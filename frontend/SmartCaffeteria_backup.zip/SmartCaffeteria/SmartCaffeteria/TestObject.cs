﻿using System;
namespace SmartCaffeteria
{
	public struct TestObject
	{
		public string status;
		public int[] data;
	}
}
