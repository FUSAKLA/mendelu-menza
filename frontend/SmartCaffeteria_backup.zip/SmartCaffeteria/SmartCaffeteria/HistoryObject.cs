﻿using System;
namespace SmartCaffeteria
{
	public struct HistoryObject
	{
		public int week_id;
		public int queue_time;
		public int level;
	}
}