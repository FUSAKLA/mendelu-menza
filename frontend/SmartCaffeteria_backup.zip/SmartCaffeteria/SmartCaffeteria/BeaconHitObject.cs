﻿using System;
namespace SmartCaffeteria
{
	public struct BeaconHitObject
	{
		public string beacon_id;
		public int user_id;
		public string hit_time;
	}
}
