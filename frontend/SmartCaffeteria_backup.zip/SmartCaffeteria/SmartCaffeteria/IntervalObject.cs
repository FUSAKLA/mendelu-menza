﻿using System;
namespace SmartCaffeteria
{
	public struct IntervalObject
	{
		public int level;
		public string start_time;
	}
}
